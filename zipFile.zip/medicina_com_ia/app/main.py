import os
import asyncio
from dotenv import load_dotenv
from fastapi import FastAPI
from contextlib import asynccontextmanager
from redis import asyncio as aioredis
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.requests import Request

from app.routers import auth_routes, websocket as ws_router ,cadastro_routes,transcription_routes,download_relatorio_routes,dashboard_routes
from app.db.init_db import create_tables
# from auth import configure_authentication  # futuro

load_dotenv()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1) Redis assíncrono compartilhado
    app.state.redis = aioredis.from_url("redis://redis:6379/0", decode_responses=True)

    # 2) Inicia watchdog de timeouts do WS (task de background)
    #    ws_router.verificar_timeouts() já existe no seu módulo.
    app.state.ws_timeout_task = asyncio.create_task(ws_router.verificar_timeouts())

    try:
        yield
    finally:
        # Cancela watchdog com segurança
        task = app.state.ws_timeout_task
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        # Fecha Redis
        await app.state.redis.close()

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None,lifespan=lifespan)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Criar tabelas ao iniciar
create_tables()

# Roteadores HTTP e WebSocket
app.include_router(auth_routes.router)
app.include_router(ws_router.router)  
app.include_router(cadastro_routes.router)
app.include_router(transcription_routes.router)
app.include_router(download_relatorio_routes.router)
app.include_router(dashboard_routes.router)
# Static e templates
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/static/html")


@app.get("/dashboard", response_class=HTMLResponse)
def render_dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

# Inicializar
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)