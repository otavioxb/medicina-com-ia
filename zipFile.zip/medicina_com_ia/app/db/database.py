# app/db/database.py
import os
import psycopg2
from psycopg2 import pool
from dotenv import load_dotenv

load_dotenv()

# Lê as configs do .env
DB_HOST = os.getenv("DB_HOST")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_MIN_CONN = int(os.getenv("DB_MIN_CONN"))
DB_MAX_CONN = int(os.getenv("DB_MAX_CONN"))

# Inicializa o pool
db_pool = psycopg2.pool.ThreadedConnectionPool(
    minconn=DB_MIN_CONN,
    maxconn=DB_MAX_CONN,
    dbname=DB_NAME,
    user=DB_USER,
    password=DB_PASSWORD,
    host=DB_HOST,
    port=DB_PORT
)

def get_db_connection():
    try:
        conn = db_pool.getconn()
        return conn
    except Exception as e:
        raise RuntimeError(f"Erro ao obter conexão com o banco: {e}")

def release_db_connection(conn):
    if conn:
        db_pool.putconn(conn)

def close_all_connections():
    db_pool.closeall()